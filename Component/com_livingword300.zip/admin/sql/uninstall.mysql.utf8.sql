-- DROP TABLE IF EXISTS `#__livingword`;
-- DROP TABLE IF EXISTS `#__livingword_links`;
-- DROP TABLE IF EXISTS `#__livingword_plans`;
-- DROP TABLE IF EXISTS `#__livingword_plans_details`;